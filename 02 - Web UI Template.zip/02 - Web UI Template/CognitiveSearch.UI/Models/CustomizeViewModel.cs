﻿namespace CognitiveSearch.UI.Models
{
    public class CustomizeViewModel
    {
        public ColorSettings NavBar { get; set; }
    }
}