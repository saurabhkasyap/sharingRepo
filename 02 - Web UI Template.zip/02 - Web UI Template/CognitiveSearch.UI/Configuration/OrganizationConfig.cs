﻿namespace CognitiveSearch.UI.Configuration
{
    public class OrganizationConfig
    {
        public string Name { get; set; }
    }
}