﻿namespace CognitiveSearch.UI.Configuration
{
    public class ApiConfig
    {
        public string Url { get; set; }
    }
}